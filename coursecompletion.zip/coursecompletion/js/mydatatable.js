$('#myFirstTable').DataTable({

   dom: 'Blfrtip',
   buttons: [
       'copyHtml5',
       'csvHtml5',
   ]
});

$('#mySecondTable').DataTable({

   dom: 'lrtip',
});

$('#example').DataTable();
$('#example1').DataTable();