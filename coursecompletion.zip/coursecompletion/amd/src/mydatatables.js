import $ from 'jquery'; import 'coursecompletion/Datatables';

$(document).ready(function() {
       $('#example').DataTable();
   });
